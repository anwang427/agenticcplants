#!/bin/bash
screen 9600 /dev/ttyUSB0
